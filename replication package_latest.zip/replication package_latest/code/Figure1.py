
# -*- coding: utf-8 -*-

"""
Created on Thu Jun  4 13:16:37 2020

This script is to make plots for "Stock Prices and Economic Activity in the Time of Coronavirus" 

@author: Dingqian Liu American University Ph.D. Candidate in Economics
@contact: dl5165a@american.edu; https://dingqianl.github.io/web/

"""

# import modules

import os
import pandas as pd
import matplotlib.pyplot as plt
import datetime


path = r'...\replication packages_latest' ## replace the directory with the one on your own hard drive.
os.chdir(path)

global_weighted = pd.read_excel(r'data\global weighted.xlsx')
advanced_weighted = pd.read_excel(r'data\advanced weighted.xlsx')
emerging_weighted = pd.read_excel(r'data\emerging weighted.xlsx')

global_weighted = global_weighted[['date', 'stock market percentage change from Feb.17']]
advanced_weighted = advanced_weighted[['date', 'stock market percentage change from Feb.17']]
emerging_weighted = emerging_weighted[['date', 'stock market percentage change from Feb.17']]

plt.rcParams.update({'font.size': 26})
fig, ax = plt.subplots(figsize=(20,12))

ax.plot(global_weighted['date'], global_weighted['stock market percentage change from Feb.17'], c = 'dodgerblue', linewidth = 3.0, label = 'Global Economy')
ax.plot(advanced_weighted['date'], advanced_weighted['stock market percentage change from Feb.17'], c = 'firebrick', linestyle='--', linewidth = 3.0, label = 'Advanced Economy')
ax.plot(emerging_weighted['date'], emerging_weighted['stock market percentage change from Feb.17'], c = 'yellowgreen', linewidth = 3.0, label = 'Emerging Market and Developing Economy (EMDE)')
ax.set_ylim( -50, 10)
plt.grid(color = 'lavender', alpha = 0.9)
plt.xticks(rotation=40)
ax.legend(['Global Economy','Advanced Economy', 'Emerging Market and Developing Economy (EMDE)'],bbox_to_anchor=[0,-0.33], loc='lower left',
           ncol=2, borderaxespad=0.)
fig.autofmt_xdate()
ax.set_xlim(left = datetime.date(2020, 2, 15))

plt.savefig(r'figure\Figure 1.jpg' , dpi=100, bbox_inches='tight')
plt.clf()



