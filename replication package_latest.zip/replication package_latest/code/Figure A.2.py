# -*- coding: utf-8 -*-
"""
This script is to make plots for "Stock Prices and Economic Activity in the Time of Coronavirus" 

@author: Dingqian Liu American University Ph.D. Candidate in Economics
@contact: dl5165a@american.edu; https://dingqianl.github.io/web/

"""
import os
#import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

##### A.2.1 ###

plt.figure(figsize=(12,5.8))
plt.rcParams.update({'font.size': 20})

fig, ax = plt.subplots(nrows=3, ncols=1, sharex = True, sharey = True,  
                        figsize=(14,18))        

fig.text(0.5, 0,"", ha = 'center', rotation = 45 ,fontsize=22)
fig.text(0.0, 0.4,"Stringency Index", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()
plt.xticks(rotation=20)

plt.ylim( 0, 100)

## panel 1, u.s., France, Canada, Switzerland, Germany ########
sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country.isin( ['United States', 'France', 'Canada', 'Switzerland', 'Germany', 'United Kingdom'])]
sub01 = sub0.loc[sub0.country == 'United States']
sub02 = sub0.loc[sub0.country == 'France']
sub03 = sub0.loc[sub0.country == 'Canada']
sub04 = sub0.loc[sub0.country == 'Switzerland']
sub05 = sub0.loc[sub0.country == 'Germany']
sub08 = sub0.loc[sub0.country == 'United Kingdom']


ax[0].plot(sub01.date, sub01['StringencyIndex'], linestyle='--', linewidth=2, label = 'United States')
ax[0].plot(sub02.date, sub02['StringencyIndex'], linestyle='-', marker='o', linewidth=2, label = 'France')
ax[0].plot(sub03.date, sub03['StringencyIndex'], linestyle='-', marker='x',linewidth=2, label = 'Canada')
ax[0].plot(sub04.date, sub04['StringencyIndex'], linestyle=':', linewidth=3, label = 'Switzerland')
ax[0].plot(sub05.date, sub05['StringencyIndex'], label = 'Germany')
#ax[0].plot(sub06.date, sub06['Stringency Index'], label = 'Germany')
#ax[0].plot(sub07.date, sub07['Stringency Index'], label = 'Germany')
ax[0].plot(sub08.date, sub08['StringencyIndex'] , linestyle='-' , marker='x', label = 'United Kingdom')

ax[0].plot(sub01.date, [70]*len(sub01.date), linestyle='-', linewidth=1,c='black')

ax[0].legend(['United States', 'France', 'Canada', 'Switzerland', 'Germany', 'United Kingdom'], loc =2)


## panel 2, Netherlands, Taiwan, Spain, Singapore, 'Belgium' ########
sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country.isin([ 'Netherlands', 'Taiwan', 'Spain', 'Singapore', 'Belgium', 'Australia'])]

sub11 = sub1.loc[sub1.country == 'Netherlands']
sub12 = sub1.loc[sub1.country == 'Taiwan']
sub13 = sub1.loc[sub1.country == 'Spain']
sub14 = sub1.loc[sub1.country == 'Singapore']
sub15 = sub1.loc[sub1.country == 'Belgium']
sub16 = sub1.loc[sub1.country == 'Australia']


ax[1].plot(sub11.date, sub11.StringencyIndex, linestyle='--', linewidth=2,label = 'Netherlands')
ax[1].plot(sub12.date, sub12.StringencyIndex, linestyle='-', marker='o', linewidth=2,label = 'Taiwan')
ax[1].plot(sub13.date, sub13.StringencyIndex, linestyle='-', marker='x', linewidth=2, label = 'Spain')
ax[1].plot(sub14.date, sub14.StringencyIndex, linestyle=':', linewidth=3, label = 'Singapore')
ax[1].plot(sub15.date, sub15.StringencyIndex, label = 'Belgium')
ax[1].plot(sub16.date, sub16.StringencyIndex, linestyle='-' , marker='x', label = 'Australia')

ax[1].plot(sub11.date, [70]*len(sub11.date), linestyle='-', linewidth=1,c='black')

ax[1].legend(['Netherlands', 'Taiwan', 'Spain', 'Singapore', 'Belgium', 'Australia'], loc =2)


## panel 3, 'Poland', 'Ireland', 'Greece', 'Slovenia', 'India' , 'Brazil'########
sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country.isin(['Poland', 'Ireland', 'Greece', 'Slovenia', 'India', 'Brazil'])]

sub21 = sub2.loc[sub2.country == 'Poland']
sub22 = sub2.loc[sub2.country == 'Ireland']
sub23 = sub2.loc[sub2.country == 'Greece']
sub24 = sub2.loc[sub2.country == 'Slovenia']
sub25 = sub2.loc[sub2.country == 'India']
sub26 = sub2.loc[sub2.country == 'Brazil']


ax[2].plot(sub21.date, sub21.StringencyIndex, linestyle='--', linewidth=2,label = 'Poland')
ax[2].plot(sub22.date, sub22.StringencyIndex, linestyle='-', marker='o', linewidth=2,label = 'Ireland')
ax[2].plot(sub23.date, sub23.StringencyIndex, linestyle='-', marker='x', linewidth=2, label = 'Greece')
ax[2].plot(sub24.date, sub24.StringencyIndex, linestyle=':', linewidth=3, label = 'Slovenia')
ax[2].plot(sub25.date, sub25.StringencyIndex, linestyle=':',marker='x', label = 'India')
ax[2].plot(sub26.date, sub26.StringencyIndex, label = 'Brazil')

ax[2].plot(sub21.date, [70]*len(sub21.date), linestyle='-', linewidth=1,c='black')

ax[2].legend(['Poland', 'Ireland', 'Greece', 'Slovenia', 'India', 'Brazil'], loc =2)

plt.savefig(r'plots\ts_string\fig A.2.1.jpg' , dpi=100, bbox_inches='tight')
plt.clf()

##### A.2.2 ###

plt.figure(figsize=(12,5.8))
plt.rcParams.update({'font.size': 20})

fig, ax = plt.subplots(nrows=3, ncols=1, sharex = True, sharey = True,  
                        figsize=(14,18))        

fig.text(0.5, 0,"", ha = 'center', rotation = 45 ,fontsize=22)
fig.text(0.0, 0.4,"Stringency Index", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()
plt.xticks(rotation=20)
plt.ylim( 0, 100)

## panel 1, 'South Africa', 'Taiwan', 'Thailand', 'Malaysia', 'Mexico', ########
sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country.isin( ['South Africa', 'Taiwan','Thailand', 'Malaysia', 'Mexico'])]
sub01 = sub0.loc[sub0.country == 'South Africa']
sub02 = sub0.loc[sub0.country ==  'Taiwan']
sub03 = sub0.loc[sub0.country == 'Thailand']
sub04 = sub0.loc[sub0.country == 'Malaysia']
sub05 = sub0.loc[sub0.country == 'Mexico']

ax[0].plot(sub01.date, sub01.StringencyIndex, linestyle='--', linewidth=2, label = 'South Africa')
ax[0].plot(sub02.date, sub02.StringencyIndex, linestyle='-', marker='o', linewidth=2, label = 'Taiwan')
ax[0].plot(sub03.date, sub03.StringencyIndex, linestyle='-', marker='x',linewidth=2, label = 'Thailand')
ax[0].plot(sub04.date, sub04.StringencyIndex, linestyle=':', linewidth=3, label = 'Malaysia')
ax[0].plot(sub05.date, sub05.StringencyIndex, label = 'Mexico')
ax[0].plot(sub01.date, [70]*len(sub01.date), linestyle='-', linewidth=1,c='black')

ax[0].legend(['South Africa', 'Taiwan', 'Thailand', 'Malaysia', 'Mexico'], loc = 2)


## panel 2, 'Chile','Qatar', 'Turkey', 'Romania', 'Argentina' ########
sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country.isin(['Chile', 'Qatar', 'Turkey', 'Romania', 'Argentina'])]

sub11 = sub1.loc[sub1.country == 'Chile']
sub12 = sub1.loc[sub1.country == 'Qatar']
sub13 = sub1.loc[sub1.country == 'Turkey']
sub14 = sub1.loc[sub1.country == 'Romania']
sub15 = sub1.loc[sub1.country == 'Argentina']


ax[1].plot(sub11.date, sub11.StringencyIndex, linestyle='--', linewidth=2,label = 'Chile')
ax[1].plot(sub12.date, sub12.StringencyIndex, linestyle='-', marker='o', linewidth=2,label = 'Qatar')
ax[1].plot(sub13.date, sub13.StringencyIndex, linestyle='-', marker='x', linewidth=2, label = 'Turkey')
ax[1].plot(sub14.date, sub14.StringencyIndex, linestyle=':', linewidth=3, label = 'Romania')
ax[1].plot(sub15.date, sub15.StringencyIndex, label = 'Argentina')
ax[1].plot(sub11.date, [70]*len(sub11.date), linestyle='-', linewidth=1,c='black')

ax[1].legend(['Chile','Qatar', 'Turkey', 'Romania', 'Argentina'], loc =2)


## panel 3, , 'Kazakhstan', 'Hungary', 'Croatia' ########
sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country.isin(['Kazakhstan', 'Hungary', 'Croatia'])]

sub21 = sub2.loc[sub2.country == 'Kazakhstan']
sub22 = sub2.loc[sub2.country == 'Hungary']
sub23 = sub2.loc[sub2.country == 'Croatia']


ax[2].plot(sub21.date, sub21.StringencyIndex, linestyle='--', linewidth=2,label = 'Kazakhstan')
ax[2].plot(sub22.date, sub22.StringencyIndex, linestyle='-', marker='o', linewidth=2,label = 'Hungary')
ax[2].plot(sub23.date, sub23.StringencyIndex, linestyle='-', marker='x', linewidth=2, label = 'Croatia')
ax[2].plot(sub21.date, [70]*len(sub21.date), linestyle='-', linewidth=1,c='black')

ax[2].legend(['Kazakhstan', 'Hungary', 'Croatia'], loc = 2)

plt.savefig(r'figure/Figure A.2.jpg', dpi = 100, bbox_inches='tight')
plt.clf()
