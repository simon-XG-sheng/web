# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 14:00:39 2021

This script is to make plots for "Stock Prices and Economic Activity in the Time of Coronavirus" 

@author: Dingqian Liu American University Ph.D. Candidate in Economics
@contact: dl5165a@american.edu; https://dingqianl.github.io/web/

"""
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

path = r'...\replication package_latest'
os.chdir(path)

mobility_deviation = pd.read_excel(r'data\Figure 8, China mobility percent deviation from baseline.xlsx')
mobility_deviation['date'] = pd.to_datetime(mobility_deviation['date'])
mobility_deviation = mobility_deviation.loc[mobility_deviation.date<='2020-05-01']
only_a = pd.read_csv(r'data\only A shares stock market deviation.csv')

only_a = only_a.iloc[7:]
only_a = only_a.reset_index(drop = True)
only_a['date'] = pd.to_datetime(only_a['date'])
only_a['stock market deviation'] = only_a['stock market deviation'].interpolate(method = 'linear')

only_a_mobility = pd.merge(mobility_deviation, only_a, on = 'date', how ='inner')
only_a_mobility['percent_deviation'].iloc[9:15] = np.nan
only_a_mobility['percent_deviation'] = only_a_mobility['percent_deviation'].interpolate(method = 'linear')


# to import stringency index and death
strin_death = pd.read_excel(r'data\china stringency and death cases.xlsx')
strin_death['date'] = pd.to_datetime(strin_death['date'], format = '%Y%m%d')

only_a_mobility_strin_death = pd.merge(only_a_mobility, strin_death, on = 'date', how = 'inner')


### plot the time path; SSE use dashline from 1/24, 1/27 to 2/3, through; 
plt.figure(figsize=(7.2,5.8))
plt.rcParams.update({'font.size': 17.5})
plt.box(False)
x = only_a_mobility_strin_death['percent_deviation']
y = only_a_mobility_strin_death['stock market deviation']

x0 =  only_a_mobility_strin_death['percent_deviation'].iloc[9:16]
y0 = only_a_mobility_strin_death['stock market deviation'].iloc[9:16]
plt.plot(x[:10], y[:10], fillstyle='full', color = 'grey',linewidth=0.5)
plt.plot(x[15:], y[15:],fillstyle='full', color = 'grey',linewidth=0.5)

plt.plot(x0, y0,'--', color = 'red')

plt.scatter(x[:10], y[:10],facecolor='lightcyan', edgecolors='royalblue')
plt.scatter(x[15:], y[15:], facecolor='lightcyan', edgecolors='royalblue')

plt.scatter(x0, y0,  facecolor='lightcyan', edgecolors='royalblue')

plt.scatter(x.iloc[0], y.iloc[0], c = 'royalblue')
plt.scatter(x.iloc[-1], y.iloc[-1], c = 'royalblue')

plt.ylim(-30,30)
plt.xlim(-70,10)

plt.grid(color = 'lavender', alpha = 0.5)

x1 = only_a_mobility_strin_death.loc[only_a_mobility_strin_death.new_death>0]['percent_deviation'].iloc[0]
y1 = only_a_mobility_strin_death.loc[only_a_mobility_strin_death.new_death>0]['stock market deviation'].iloc[0]
z1 = only_a_mobility_strin_death.loc[only_a_mobility_strin_death.new_death>0]['date'].dt.strftime('%m/%d').iloc[0]
plt.scatter(x1,y1, marker = 'o', s =110, c = 'darkorange')
plt.annotate(z1, (x1, y1), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                    connectionstyle="arc3"),
             xytext=(10,-35),ha='center')

x2 = only_a_mobility_strin_death.loc[only_a_mobility_strin_death['stringency'] >70]['percent_deviation'].iloc[0]
y2 = only_a_mobility_strin_death.loc[only_a_mobility_strin_death['stringency'] >70]['stock market deviation'].iloc[0]
z2 = only_a_mobility_strin_death.loc[only_a_mobility_strin_death['stringency'] >70]['date'].dt.strftime('%m/%d').iloc[0]
plt.scatter(x2,y2, marker = 'o', s =110, c = 'limegreen')
plt.annotate(z2, (x2, y2), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                    connectionstyle="arc3"),
             xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

c3 = only_a_mobility_strin_death.iloc[-30:]
x3 = c3.loc[c3['stringency'] <=70]['percent_deviation'].iloc[0]
y3 = c3.loc[c3['stringency'] <=70]['stock market deviation'].iloc[0]
z3 = c3.loc[c3['stringency'] <=70]['date'].dt.strftime('%m/%d').iloc[0]
plt.scatter(x3,y3, marker = 'o', s =110, c = 'crimson')
plt.annotate(z3,
    xy=(x3, y3), xycoords='data',
    xytext=(-15, -30), textcoords='offset points',
    arrowprops=dict(arrowstyle="->",
                    connectionstyle="arc3"))


dates0 = only_a_mobility_strin_death.date
dates0 = dates0.dt.strftime('%m/%d')
plt.annotate(dates0.iloc[0], (x.iloc[0], y.iloc[0]), textcoords="offset points",
             xytext=(0,20),ha='center')
plt.annotate(dates0.iloc[-1], (x.iloc[-1], y.iloc[-1]), textcoords="offset points",
         xytext=(0,20),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
plt.annotate(dates0.iloc[9], (x.iloc[9], y.iloc[9]), textcoords="offset points",
         xytext=(-10,20),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3")) #1/24
plt.annotate(dates0.iloc[14], (x.iloc[14], y.iloc[14]), textcoords="offset points",
         xytext=(0,20),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3")) #1/31
plt.annotate(dates0.iloc[18], (x.iloc[18], y.iloc[18]), textcoords="offset points",
         xytext=(0,20),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3")) #2/6
plt.annotate(dates0.iloc[38], (x.iloc[38], y.iloc[38]), textcoords="offset points",
         xytext=(0,20),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3")) #3/5
plt.annotate(dates0.iloc[63], (x.iloc[63], y.iloc[63]), textcoords="offset points",
         xytext=(0,20),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3")) #4/10


#plt.title('China')
plt.xlabel("Mobility, Percentage Change from Baseline")
plt.ylabel("A Shares, Percent Deviation from January 13")

plt.savefig(r'figure\Figure 8.jpg', dpi=100, bbox_inches='tight')
plt.clf()

