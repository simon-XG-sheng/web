# -*- coding: utf-8 -*-

"""
Created on Thu Jun  4 13:16:37 2020

This script is to make plots for "Stock Prices and Economic Activity in the Time of Coronavirus" 

@author: Dingqian Liu American University Ph.D. Candidate in Economics
@contact: dl5165a@american.edu; https://dingqianl.github.io/web/

"""

# import modules

import os
#import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


path = r'...\replication packages_latest' ## replace the directory with the one on your hard drive.
os.chdir(path)


equity_mob_death_npi = pd.read_csv(r'data\data_individual plots.csv')
equity_mob_death_npi['date'] = pd.to_datetime(equity_mob_death_npi['date'])
########## Figure 5 & Figure A.3  ##################################

# The order of the countries by the market cap:
# United States, Japan, United Kingdom, France, India, Canada, Switzerland
# Germany, Australia, South Korea, Netherlands, Brazil, South Africa
# Taiwan, Spain, Singapore, Sweden, Thailand, Malaysia
# Mexico, Belgium, Chile, Qatar, Poland, Turkey
# Romania, Ireland, New Zealand, Argentina, Greece, Kazakhstan
# Hungary, Croatia, Slovenia

# advanced economy, by market cap (20)
# United States, Japan, United Kingdom, France, Canada, Switzerland 
# Germany, Australia, South Korea, Netherlands, Taiwan, Spain 
# Singapore, Sweden, Belgium, Poland, Ireland, New Zealand
# Greece, Slovenia

# EMDE, by market cap (14)
# India, Brazil, South Africa, Thailand
# Malaysia, Mexico, Chile, Qatar, Turkey, Romania
# Argentina, Kazakhstan, Hungary, Crotia

################# Figure 5 #########################

######first page (United States, Japan, United Kingdom, France, Canada, Switzerland ) ####
plt.figure(figsize=(15,19))
plt.rcParams.update({'font.size': 17.5})

fig, ax = plt.subplots(nrows=3, ncols=2, sharex = True, sharey = True,  
                        figsize=(15,18))        
fig.subplots_adjust(left=0.5)
fig.subplots_adjust(bottom = 0.4)

fig.text(0.5, 0,"Percent Workplace Mobility Deviation from Baseline", ha = 'center', fontsize=22)
fig.text(0, 0.3,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()

plt.axis([-82, 22, -65, 15])

sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'United States']
s0x = sub0['workplace_percent_change_from_baseline']
s0y = sub0['stock market percentage change from Feb.17']
s0w = round(sub0['weight'].iloc[0], 4)

sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Japan']
s1x = sub1['workplace_percent_change_from_baseline']
s1y = sub1['stock market percentage change from Feb.17']
s1w = round(sub1['weight'].iloc[0], 4)

sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'United Kingdom']
s2x = sub2['workplace_percent_change_from_baseline']
s2y = sub2['stock market percentage change from Feb.17']
s2w = round(sub2['weight'].iloc[0], 4)

sub3 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'France']
s3x = sub3['workplace_percent_change_from_baseline']
s3y = sub3['stock market percentage change from Feb.17']
s3w = round(sub3['weight'].iloc[0], 4)

sub4 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Canada']
s4x = sub4['workplace_percent_change_from_baseline']
s4y = sub4['stock market percentage change from Feb.17']
s4w = round(sub4['weight'].iloc[0], 4)

sub5 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Switzerland']
s5x = sub5['workplace_percent_change_from_baseline']
s5y = sub5['stock market percentage change from Feb.17']
s5w = round(sub5['weight'].iloc[0], 4)


ax[0, 0].set_title('United States' + ' (' +"{:.2%}".format(s0w) + ')')
ax[0, 1].set_title('Japan' + ' (' +"{:.2%}".format(s1w) + ')')
ax[1, 0].set_title('United Kingdom' + ' (' +"{:.2%}".format(s2w) + ')')
ax[1, 1].set_title('France' + ' (' +"{:.2%}".format(s3w) + ')')
ax[2, 0].set_title('Canada' + ' (' +"{:.2%}".format(s4w) + ')')
ax[2, 1].set_title('Switzerland' + ' (' +"{:.2%}".format(s5w) + ')')

ax[0, 0].set_frame_on(False)
ax[0, 1].set_frame_on(False)
ax[1, 0].set_frame_on(False)
ax[1, 1].set_frame_on(False)
ax[2, 0].set_frame_on(False)
ax[2, 1].set_frame_on(False)

ax[0, 0].grid(color = 'lavender', alpha = 0.5)
ax[0, 1].grid(color = 'lavender', alpha = 0.5)
ax[1, 0].grid(color = 'lavender', alpha = 0.5)
ax[1, 1].grid(color = 'lavender', alpha = 0.5)
ax[2, 0].grid(color = 'lavender', alpha = 0.5)
ax[2, 1].grid(color = 'lavender', alpha = 0.5)

for ax0 in ax.flat:
    ax0.label_outer()

ax[0, 0].plot(s0x, s0y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 0].scatter(s0x, s0y, facecolor='lightcyan', edgecolors='royalblue')

ax[0, 1].plot(s1x, s1y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 1].scatter(s1x, s1y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 0].plot(s2x, s2y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 0].scatter(s2x, s2y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 1].plot(s3x, s3y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 1].scatter(s3x, s3y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 0].plot(s4x, s4y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 0].scatter(s4x, s4y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 1].plot(s5x, s5y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 1].scatter(s5x, s5y, facecolor='lightcyan', edgecolors='royalblue')

plt.tight_layout()

### United States 0 ###
try:
    x01 = sub0.loc[sub0.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y01 = sub0.loc[sub0.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z01 = sub0.loc[sub0.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x01,y01, s =100, c = 'darkorange')
    ax[0, 0].annotate(z01, (x01, y01), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(38,-35),ha='center')

except IndexError:
    pass
    
try:
    x02 = sub0.loc[sub0['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y02 = sub0.loc[sub0['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z02 = sub0.loc[sub0['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x02,y02, s =100, c = 'limegreen')
    ax[0, 0].annotate(z02, (x02, y02), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c03 = sub0.iloc[-30:]
    x03 = c03.loc[c03['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y03 = c03.loc[c03['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z03 = c03.loc[c03['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x03,y03,  s =100, c = 'crimson')
    ax[0, 0].annotate(z03,
        xy=(x03, y03), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass


dates0 = sub0.date
dates0 = dates0.dt.strftime('%B %d')
ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')

ax[0, 0].annotate(dates0.iloc[0], (s0x.iloc[0], s0y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 0].annotate(dates0.iloc[-1], (s0x.iloc[-1], s0y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Japan 1 #######
try:
    x11 = sub1.loc[sub1.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y11 = sub1.loc[sub1.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z11 = sub1.loc[sub1.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x11,y11, s =100, c = 'darkorange')
    ax[0, 1].annotate(z11, (x11, y11), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-45),ha='center')

except IndexError:
    pass
    
try:
    x12 = sub1.loc[sub1['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y12 = sub1.loc[sub1['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z12 = sub1.loc[sub1['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x12,y12, s =100, c = 'limegreen')
    ax[0, 1].annotate(z12, (x12, y12), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c13 = sub1.iloc[-30:]
    x13 = c13.loc[c13['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y13 = c13.loc[c13['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z13 = c13.loc[c13['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x13,y13, s =100, c = 'crimson')
    ax[0, 1].annotate(z13,
        xy=(x13, y13), xycoords='data',
        xytext=(-50, -40), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates1 = sub1.date
dates1 = dates1.dt.strftime('%B %d')
ax[0, 1].scatter(s1x.iloc[0], s1y.iloc[0], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[-1], s1y.iloc[-1], c = 'royalblue')

ax[0, 1].annotate(dates1.iloc[0], (s1x.iloc[0], s1y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 1].annotate(dates1.iloc[-1], (s1x.iloc[-1], s1y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### For united kingdom 2 #######
try:
    x21 = sub2.loc[sub2.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y21 = sub2.loc[sub2.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z21 = sub2.loc[sub2.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x21,y21, s =100, c = 'darkorange')
    ax[1, 0].annotate(z21, (x21, y21), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x22 = sub2.loc[sub2['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y22 = sub2.loc[sub2['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z22 = sub2.loc[sub2['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x22,y22, s =100, c = 'limegreen')
    ax[1, 0].annotate(z22, (x22, y22), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c23 = sub2.iloc[-30:]
    x23 = c23.loc[c23['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y23 = c23.loc[c23['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z23 = c23.loc[c23['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x23,y23, s =100, c = 'crimson')
    ax[1, 0].annotate(z23,
        xy=(x23, y23), xycoords='data',
        xytext=(10, -40), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates2 = sub2.date
dates2 = dates2.dt.strftime('%B %d')
ax[1, 0].scatter(s2x.iloc[0], s2y.iloc[0], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[-1], s2y.iloc[-1], c = 'royalblue')

ax[1, 0].annotate(dates2.iloc[0], (s2x.iloc[0], s2y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 0].annotate(dates2.iloc[-1], (s2x.iloc[-1], s2y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### France 3 #######
try:
    x31 = sub3.loc[sub3.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y31 = sub3.loc[sub3.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z31 = sub3.loc[sub3.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x31,y31, s = 100, c = 'darkorange')
    ax[1, 1].annotate(z31, (x31, y31), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-40,-35),ha='center')

except IndexError:
    pass
    
try:
    x32 = sub3.loc[sub3['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = sub3.loc[sub3['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = sub3.loc[sub3['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32, s = 100, c = 'limegreen')
    ax[1, 1].annotate(z32, (x32, y32), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c33 = sub3.iloc[-30:]
    x33 = c33.loc[c33['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y33 = c33.loc[c33['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z33 = c33.loc[c33['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x33,y33, s = 100, c = 'crimson')
    ax[1, 1].annotate(z33,
        xy=(x33, y33), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates3 = sub3.date
dates3 = dates3.dt.strftime('%B %d')
ax[1, 1].scatter(s3x.iloc[0], s3y.iloc[0], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[-1], s3y.iloc[-1], c = 'royalblue')

ax[1, 1].annotate(dates3.iloc[0], (s3x.iloc[0], s3y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 1].annotate(dates3.iloc[-1], (s3x.iloc[-1], s3y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Canada 4 #######
try:
    x41 = sub4.loc[sub4.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y41 = sub4.loc[sub4.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z41 = sub4.loc[sub4.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x41,y41, s = 100, c = 'darkorange')
    ax[2, 0].annotate(z41, (x41, y41), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x42 = sub4.loc[sub4['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y42 = sub4.loc[sub4['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z42 = sub4.loc[sub4['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x42,y42, s =100, c = 'limegreen')
    ax[2, 0].annotate(z42, (x42, y42), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c43 = sub4.iloc[-30:]
    x43 = c43.loc[c43['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y43 = c43.loc[c43['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z43 = c43.loc[c43['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x43,y43, s = 100, c = 'crimson')
    ax[2, 1].annotate(z43,
        xy=(x43, y43), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass


dates4 = sub4.date
dates4 = dates4.dt.strftime('%B %d')
ax[2, 0].scatter(s4x.iloc[0], s4y.iloc[0], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[-1], s4y.iloc[-1], c = 'royalblue')

ax[2, 0].annotate(dates4.iloc[0], (s4x.iloc[0], s4y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 0].annotate(dates4.iloc[-1], (s4x.iloc[-1], s4y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Switzerland 5 #######
try:
    x51 = sub5.loc[sub5.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y51 = sub5.loc[sub5.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z51 = sub5.loc[sub5.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x51,y51,  s = 100, c = 'darkorange')
    ax[2, 1].annotate(z51, (x51, y51), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(38,-35),ha='center')

except IndexError:
    pass
    
try:
    x52 = sub5.loc[sub5['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y52 = sub5.loc[sub5['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z52 = sub5.loc[sub5['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x52,y52, s = 100, c = 'limegreen')
    ax[2, 1].annotate(z52, (x52, y52), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c53 = sub5.iloc[-30:]
    x53 = c53.loc[c53['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y53 = c53.loc[c53['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z53 = c53.loc[c53['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x53,y53,  s = 100, c = 'crimson')
    ax[2, 1].annotate(z53,
        xy=(x53, y53), xycoords='data',
        xytext=(-30, -40), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates5 = sub5.date
dates5 = dates5.dt.strftime('%B %d')
ax[2, 1].scatter(s5x.iloc[0], s5y.iloc[0], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[-1], s5y.iloc[-1], c = 'royalblue')

ax[2, 1].annotate(dates5.iloc[0], (s5x.iloc[0], s5y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 1].annotate(dates5.iloc[-1], (s5x.iloc[-1], s5y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

plt.savefig(r'figure\trace_equity_mobility_p1.jpg' , dpi=100, bbox_inches='tight')
plt.clf()


####### for page 2 (Germany, Australia, South Korea, Netherlands, Taiwan, Spain)

plt.figure(figsize=(7.2,5.8))
plt.rcParams.update({'font.size': 17.5})

fig, ax = plt.subplots(nrows=3, ncols=2, sharex = True, sharey = True,  
                        figsize=(14,18))        
fig.subplots_adjust(left=0.5, bottom = 0.8)

#(ax0, ax1), (ax2, ax3), (ax4, ax5) = ax
  #  ax0 = fig.add_subplot(111)
#plt.xlabel("Percent Workplace … Percent Change …")
fig.text(0.5, 0,"Percent Workplace Mobility Deviation from Baseline", ha = 'center', fontsize=22)
fig.text(0, 0.3,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()

plt.axis([-92, 27, -70, 27])

sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Germany']
s0x = sub0['workplace_percent_change_from_baseline']
s0y = sub0['stock market percentage change from Feb.17']
s0w = round(sub0['weight'].iloc[0], 4)

sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Australia']
s1x = sub1['workplace_percent_change_from_baseline']
s1y = sub1['stock market percentage change from Feb.17']
s1w = round(sub1['weight'].iloc[0], 4)

sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'South Korea']
s2x = sub2['workplace_percent_change_from_baseline']
s2y = sub2['stock market percentage change from Feb.17']
s2w = round(sub2['weight'].iloc[0], 4)

sub3 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Netherlands']
s3x = sub3['workplace_percent_change_from_baseline']
s3y = sub3['stock market percentage change from Feb.17']
s3w = round(sub3['weight'].iloc[0], 4)

sub4 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Taiwan']
s4x = sub4['workplace_percent_change_from_baseline']
s4y = sub4['stock market percentage change from Feb.17']
s4w = round(sub4['weight'].iloc[0], 4)

sub5 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Spain']
s5x = sub5['workplace_percent_change_from_baseline']
s5y = sub5['stock market percentage change from Feb.17']
s5w = round(sub5['weight'].iloc[0], 4)

ax[0, 0].set_title('Germany' + ' (' +"{:.2%}".format(s0w) + ')')
ax[0, 1].set_title('Australia' + ' (' +"{:.2%}".format(s1w) + ')')
ax[1, 0].set_title('South Korea' + ' (' +"{:.2%}".format(s2w) + ')')
ax[1, 1].set_title('Netherlands' + ' (' +"{:.2%}".format(s3w) + ')')
ax[2, 0].set_title('Taiwan' + ' (' +"{:.2%}".format(s4w) + ')')
ax[2, 1].set_title('Spain' + ' (' +"{:.2%}".format(s5w) + ')')

ax[0, 0].set_frame_on(False)
ax[0, 1].set_frame_on(False)
ax[1, 0].set_frame_on(False)
ax[1, 1].set_frame_on(False)
ax[2, 0].set_frame_on(False)
ax[2, 1].set_frame_on(False)

ax[0, 0].grid(color = 'lavender', alpha = 0.5)
ax[0, 1].grid(color = 'lavender', alpha = 0.5)
ax[1, 0].grid(color = 'lavender', alpha = 0.5)
ax[1, 1].grid(color = 'lavender', alpha = 0.5)
ax[2, 0].grid(color = 'lavender', alpha = 0.5)
ax[2, 1].grid(color = 'lavender', alpha = 0.5)


for ax0 in ax.flat:
    ax0.label_outer()

ax[0, 0].plot(s0x, s0y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 0].scatter(s0x, s0y, facecolor='lightcyan', edgecolors='royalblue')


ax[0, 1].plot(s1x, s1y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 1].scatter(s1x, s1y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 0].plot(s2x, s2y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 0].scatter(s2x, s2y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 1].plot(s3x, s3y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 1].scatter(s3x, s3y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 0].plot(s4x, s4y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 0].scatter(s4x, s4y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 1].plot(s5x, s5y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 1].scatter(s5x, s5y, facecolor='lightcyan', edgecolors='royalblue')
plt.tight_layout()

ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[0], s1y.iloc[0], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[-1], s1y.iloc[-1], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[0], s2y.iloc[0], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[-1], s2y.iloc[-1], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[0], s3y.iloc[0], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[-1], s3y.iloc[-1], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[0], s4y.iloc[0], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[-1], s4y.iloc[-1], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[0], s5y.iloc[0], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[-1], s5y.iloc[-1], c = 'royalblue')


##### Germany 0 #######
try:
    x01 = sub0.loc[sub0.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y01 = sub0.loc[sub0.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z01 = sub0.loc[sub0.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x01,y01,  s = 100, c = 'darkorange')
    ax[0, 0].annotate(z01, (x01, y01), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x02 = sub0.loc[sub0['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y02 = sub0.loc[sub0['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z02 = sub0.loc[sub0['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x02,y02, s =200, c = 'limegreen')
    ax[0, 0].annotate(z02, (x02, y02), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c03 = sub0.iloc[-30:]
    x03 = c03.loc[c03['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y03 = c03.loc[c03['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z03 = c03.loc[c03['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x03,y03,  s = 100, c = 'crimson')
    ax[0, 0].annotate(z03,
        xy=(x03, y03), xycoords='data',
        xytext=(-40, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass


dates0 = sub0.date
dates0 = dates0.dt.strftime('%B %d')
ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')

ax[0, 0].annotate(dates0.iloc[0], (s0x.iloc[0], s0y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 0].annotate(dates0.iloc[-1], (s0x.iloc[-1], s0y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

### Australia 1 ###
try:
    x11 = sub1.loc[sub1.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y11 = sub1.loc[sub1.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z11 = sub1.loc[sub1.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x11,y11, s = 100, c = 'darkorange')
    ax[0, 1].annotate(z11, (x11, y11), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-30,-35),ha='center')

except IndexError:
    pass
    
try:
    x12 = sub1.loc[sub1['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y12 = sub1.loc[sub1['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z12 = sub1.loc[sub1['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x12,y12, s = 100, c = 'limegreen')
    ax[0, 1].annotate(z12, (x12, y12), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c13 = sub1.iloc[-30:]
    x13 = c13.loc[c13['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y13 = c13.loc[c13['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z13 = c13.loc[c13['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x13,y13, s = 100, c = 'crimson')
    ax[0, 1].annotate(z13,
        xy=(x13, y13), xycoords='data',
        xytext=(-50, 10), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates1 = sub1.date
dates1 = dates1.dt.strftime('%B %d')
ax[0, 1].annotate(dates1.iloc[0], (s1x.iloc[0], s1y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 1].annotate(dates1.iloc[-1], (s1x.iloc[-1], s1y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

### South Korea 2###
try:
    x21 = sub2.loc[sub2.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y21 = sub2.loc[sub2.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z21 = sub2.loc[sub2.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x21,y21, c = 'darkorange', s = 100)
    ax[1, 0].annotate(z21, (x21, y21), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(20,-5),ha='center')

except IndexError:
    pass
    
try:
    x22 = sub2.loc[sub2['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y22 = sub2.loc[sub2['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z22 = sub2.loc[sub2['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x22,y22, c = 'limegreen' , s = 100)
    ax[1, 0].annotate(z22, (x22, y22), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c23 = sub2.iloc[-30:]
    x23 = c23.loc[c23['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y23 = c23.loc[c23['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z23 = c23.loc[c23['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x23,y23, s = 100, c = 'crimson')
    ax[1, 0].annotate(z23,
        xy=(x23, y23), xycoords='data',
        xytext=(40,-20), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass


dates2 = sub2.date
dates2 = dates2.dt.strftime('%B %d')
ax[1, 0].annotate(dates2.iloc[0], (s2x.iloc[0], s2y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 0].annotate(dates2.iloc[-1], (s2x.iloc[-1], s2y.iloc[-1]), textcoords="offset points",
         xytext=(-60,-30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Netherlands 3 #######
try:
    x31 = sub3.loc[sub3.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y31 = sub3.loc[sub3.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z31 = sub3.loc[sub3.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x31,y31, s = 100, c = 'darkorange')
    ax[1, 1].annotate(z31, (x31, y31), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x32 = sub3.loc[sub3['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = sub3.loc[sub3['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = sub3.loc[sub3['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32, s = 100, c = 'limegreen')
    ax[1, 1].annotate(z32, (x32, y32), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c33 = sub3.iloc[-30:]
    x33 = c33.loc[c33['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y33 = c33.loc[c33['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z33 = c33.loc[c33['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x33,y33, s = 100, c = 'crimson')
    ax[1, 1].annotate(z33,
        xy=(x33, y33), xycoords='data',
        xytext=(-75, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates3 = sub3.date
dates3 = dates3.dt.strftime('%B %d')
ax[1, 1].annotate(dates3.iloc[0], (s3x.iloc[0], s3y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 1].annotate(dates3.iloc[-1], (s3x.iloc[-1], s3y.iloc[-1]), textcoords="offset points",
         xytext=(10,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Taiwan 4 #######
try:
    x41 = sub4.loc[sub4.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y41 = sub4.loc[sub4.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z41 = sub4.loc[sub4.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x41,y41, s = 100, c = 'darkorange')
    ax[2, 0].annotate(z41, (x41, y41), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(15,-35),ha='center')

except IndexError:
    pass
    
try:
    x42 = sub4.loc[sub4['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y42 = sub4.loc[sub4['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z42 = sub4.loc[sub4['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x42,y42, s = 100, c = 'limegreen')
    ax[2, 0].annotate(z42, (x42, y42), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c43 = sub4.iloc[-30:]
    x43 = c43.loc[c43['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y43 = c43.loc[c43['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z43 = c43.loc[c43['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x43,y43,  s = 100, c = 'crimson')
    ax[2, 0].annotate(z43,
        xy=(x43, y43), xycoords='data',
        xytext=(-90, 0), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates4 = sub4.date
dates4 = dates4.dt.strftime('%B %d')
ax[2, 0].annotate(dates4.iloc[0], (s4x.iloc[0], s4y.iloc[0]), textcoords="offset points",
             xytext=(-40,10),ha='center')
ax[2, 0].annotate(dates4.iloc[-1], (s4x.iloc[-1], s4y.iloc[-1]), textcoords="offset points",
         xytext=(30,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Spain 5 #######
try:
    x51 = sub5.loc[sub5.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y51 = sub5.loc[sub5.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z51 = sub5.loc[sub5.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x51,y51, s = 100, c = 'darkorange')
    ax[2, 1].annotate(z51, (x51, y51), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x52 = sub5.loc[sub5['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y52 = sub5.loc[sub5['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z52 = sub5.loc[sub5['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x52,y52, s = 100, c = 'limegreen')
    ax[2, 1].annotate(z52, (x52, y52), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c53 = sub5.iloc[-30:]
    x53 = c53.loc[c53['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y53 = c53.loc[c53['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z53 = c53.loc[c53['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x53,y53, s = 100, c = 'crimson')
    ax[2, 1].annotate(z53,
        xy=(x53, y53), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates5 = sub5.date
dates5 = dates5.dt.strftime('%B %d')
ax[2, 1].annotate(dates5.iloc[0], (s5x.iloc[0], s5y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 1].annotate(dates5.iloc[-1], (s5x.iloc[-1], s5y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

plt.savefig(r'figure\trace_equity_mobility_p2.jpg' , dpi=100, bbox_inches='tight')
plt.clf()


##### page 3 ( Singapore, Sweden, Belgium, Poland, Ireland, New Zealand)

plt.figure(figsize=(7.2,5.8))
plt.rcParams.update({'font.size': 17.5})

fig, ax = plt.subplots(nrows=3, ncols=2, sharex = True, sharey = True,  
                        figsize=(14,18))        
fig.subplots_adjust(left=0.5, bottom = 0.5)
fig.text(0.5, 0,"Percent Workplace Mobility Deviation from Baseline", ha = 'center', fontsize=22)
fig.text(0, 0.3,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()

plt.axis([-92, 35, -85, 35])

sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Singapore']
s0x = sub0['workplace_percent_change_from_baseline']
s0y = sub0['stock market percentage change from Feb.17']
s0w = round(sub0['weight'].iloc[0], 4)

sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Sweden']
s1x = sub1['workplace_percent_change_from_baseline']
s1y = sub1['stock market percentage change from Feb.17']
s1w = round(sub1['weight'].iloc[0], 4)

sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Belgium']
s2x = sub2['workplace_percent_change_from_baseline']
s2y = sub2['stock market percentage change from Feb.17']
s2w = round(sub2['weight'].iloc[0], 4)

sub3 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Poland']
s3x = sub3['workplace_percent_change_from_baseline']
s3y = sub3['stock market percentage change from Feb.17']
s3w = round(sub3['weight'].iloc[0], 4)

sub4 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Ireland']
s4x = sub4['workplace_percent_change_from_baseline']
s4y = sub4['stock market percentage change from Feb.17']
s4w = round(sub4['weight'].iloc[0], 4)

sub5 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'New Zealand']
s5x = sub5['workplace_percent_change_from_baseline']
s5y = sub5['stock market percentage change from Feb.17']
s5w = round(sub5['weight'].iloc[0], 4)

ax[0, 0].set_title('Singapore' + ' (' +"{:.2%}".format(s0w) + ')')
ax[0, 1].set_title('Sweden' + ' (' +"{:.2%}".format(s1w) + ')')
ax[1, 0].set_title('Belgium' + ' (' +"{:.2%}".format(s2w) + ')')
ax[1, 1].set_title('Poland' + ' (' +"{:.2%}".format(s3w) + ')')
ax[2, 0].set_title('Ireland' + ' (' +"{:.2%}".format(s4w) + ')')
ax[2, 1].set_title('New Zealand' + ' (' +"{:.2%}".format(s5w) + ')')

ax[0, 0].set_frame_on(False)
ax[0, 1].set_frame_on(False)
ax[1, 0].set_frame_on(False)
ax[1, 1].set_frame_on(False)
ax[2, 0].set_frame_on(False)
ax[2, 1].set_frame_on(False)

ax[0, 0].grid(color = 'lavender', alpha = 0.5)
ax[0, 1].grid(color = 'lavender', alpha = 0.5)
ax[1, 0].grid(color = 'lavender', alpha = 0.5)
ax[1, 1].grid(color = 'lavender', alpha = 0.5)
ax[2, 0].grid(color = 'lavender', alpha = 0.5)
ax[2, 1].grid(color = 'lavender', alpha = 0.5)

for ax0 in ax.flat:
    ax0.label_outer()

ax[0, 0].plot(s0x, s0y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 0].scatter(s0x, s0y, facecolor='lightcyan', edgecolors='royalblue')


ax[0, 1].plot(s1x, s1y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 1].scatter(s1x, s1y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 0].plot(s2x, s2y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 0].scatter(s2x, s2y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 1].plot(s3x, s3y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 1].scatter(s3x, s3y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 0].plot(s4x, s4y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 0].scatter(s4x, s4y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 1].plot(s5x, s5y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 1].scatter(s5x, s5y, facecolor='lightcyan', edgecolors='royalblue')

plt.tight_layout()

ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[0], s1y.iloc[0], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[-1], s1y.iloc[-1], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[0], s2y.iloc[0], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[-1], s2y.iloc[-1], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[0], s3y.iloc[0], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[-1], s3y.iloc[-1], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[0], s4y.iloc[0], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[-1], s4y.iloc[-1], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[0], s5y.iloc[0], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[-1], s5y.iloc[-1], c = 'royalblue')


##### Singapore 0 #######
try:
    x01 = sub0.loc[sub0.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y01 = sub0.loc[sub0.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z01 = sub0.loc[sub0.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x01,y01,  s = 100, c = 'darkorange')
    ax[0, 0].annotate(z01, (x01, y01), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(20,-35),ha='center')

except IndexError:
    pass
    
try:
    x02 = sub0.loc[sub0['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y02 = sub0.loc[sub0['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z02 = sub0.loc[sub0['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x02,y02, s = 100, c = 'limegreen')
    ax[0, 0].annotate(z02, (x02, y02), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c03 = sub0.iloc[-30:]
    x03 = c03.loc[c03['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y03 = c03.loc[c03['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z03 = c03.loc[c03['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x03,y03, s = 100, c = 'crimson')
    ax[0, 0].annotate(z03,
        xy=(x03, y03), xycoords='data',
        xytext=(0, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates0 = sub0.date
dates0 = dates0.dt.strftime('%B %d')
ax[0, 0].annotate(dates0.iloc[0], (s0x.iloc[0], s0y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 0].annotate(dates0.iloc[-1], (s0x.iloc[-1], s0y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Sweden 1 #######
try:
    x11 = sub1.loc[sub1.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y11 = sub1.loc[sub1.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z11 = sub1.loc[sub1.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x11,y11, s = 100, c = 'darkorange')
    ax[0, 1].annotate(z11, (x11, y11), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x12 = sub1.loc[sub1['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y12 = sub1.loc[sub1['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z12 = sub1.loc[sub1['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x12,y12, s = 100, c = 'limegreen')
    ax[0, 1].annotate(z12, (x12, y12), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c13 = sub1.iloc[-30:]
    x13 = c13.loc[c13['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y13 = c13.loc[c13['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z13 = c13.loc[c13['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x13,y13, s =100, c = 'crimson')
    ax[0, 1].annotate(z11,
        xy=(x13, y13), xycoords='data',
        xytext=(-30, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass



dates1 = sub1.date
dates1 = dates1.dt.strftime('%B %d')
ax[0, 1].annotate(dates1.iloc[0], (s1x.iloc[0], s1y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 1].annotate(dates1.iloc[-1], (s1x.iloc[-1], s1y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### For Belgium 2 #######
try:
    x21 = sub2.loc[sub2.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y21 = sub2.loc[sub2.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z21 = sub2.loc[sub2.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x21,y21, s =100, c = 'darkorange')
    ax[1, 0].annotate(z21, (x21, y21), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x22 = sub2.loc[sub2['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y22 = sub2.loc[sub2['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z22 = sub2.loc[sub2['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x22,y22, s =100, c = 'limegreen')
    ax[1, 0].annotate(z22, (x22, y22), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c23 = sub2.iloc[-30:]
    x23 = c23.loc[c23['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y23 = c23.loc[c23['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z23 = c23.loc[c23['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x23,y23, s = 100, c = 'crimson')
    ax[1, 0].annotate(z23,
        xy=(x23, y23), xycoords='data',
        xytext=(-50, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass


dates2 = sub2.date
dates2 = dates2.dt.strftime('%B %d')
ax[1, 0].annotate(dates2.iloc[0], (s2x.iloc[0], s2y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 0].annotate(dates2.iloc[-1], (s2x.iloc[-1], s2y.iloc[-1]), textcoords="offset points",
         xytext=(20,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


### Poland 3 ###
try:
    x31 = sub3.loc[sub3.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y31 = sub3.loc[sub3.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z31 = sub3.loc[sub3.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x31,y31,  s = 100, c = 'darkorange')
    ax[1, 1].annotate(z31, (x31, y31), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x32 = sub3.loc[sub3['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = sub3.loc[sub3['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = sub3.loc[sub3['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32,  s = 100, c = 'limegreen')
    ax[1, 1].annotate(z32, (x32, y32), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-25,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c32 = sub3.iloc[-30:]
    x32 = c32.loc[c32['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = c32.loc[c32['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = c32.loc[c32['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32,  s = 100, c = 'crimson')
    ax[1, 1].annotate(z32,
        xy=(x32, y32), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates3 = sub3.date
dates3 = dates3.dt.strftime('%B %d')
ax[1, 1].annotate(dates3.iloc[0], (s3x.iloc[0], s3y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 1].annotate(dates3.iloc[-1], (s3x.iloc[-1], s3y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Ireland 4 #######
try:
    x41 = sub4.loc[sub4.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y41 = sub4.loc[sub4.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z41 = sub4.loc[sub4.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x41,y41, s = 100, c = 'darkorange')
    ax[2, 0].annotate(z41, (x41, y41), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-40,25),ha='center')

except IndexError:
    pass
    
try:
    x42 = sub4.loc[sub4['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y42 = sub4.loc[sub4['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z42 = sub4.loc[sub4['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x42,y42,  s =100, c = 'limegreen')
    ax[2, 0].annotate(z42, (x42, y42), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c43 = sub4.iloc[-30:]
    x43 = c43.loc[c43['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y43 = c43.loc[c43['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z43 = c43.loc[c43['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x43,y43,  s =100, c = 'crimson')
    ax[2, 0].annotate(z43,
        xy=(x43, y43), xycoords='data',
        xytext=(-40, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates4 = sub4.date
dates4 = dates4.dt.strftime('%B %d')
ax[2, 0].annotate(dates4.iloc[0], (s4x.iloc[0], s4y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 0].annotate(dates4.iloc[-1], (s4x.iloc[-1], s4y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### New Zealand 5 #######
try:
    x51 = sub5.loc[sub5.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y51 = sub5.loc[sub5.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z51 = sub5.loc[sub5.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x51,y51,  s =100, c = 'darkorange')
    ax[2, 1].annotate(z51, (x51, y51), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(10,-45),ha='center')

except IndexError:
    pass
    
try:
    x52 = sub5.loc[sub5['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y52 = sub5.loc[sub5['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z52 = sub5.loc[sub5['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x52, y52,  s =100, c = 'limegreen')
    ax[2, 1].annotate(z52, (x52, y52), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c53 = sub5.iloc[-30:]
    x53 = c53.loc[c53['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y53 = c53.loc[c53['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z53 = c53.loc[c53['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x53,y53,  s =100, c = 'crimson')
    ax[2, 1].annotate(z53,
        xy=(x53, y53), xycoords='data',
        xytext=(-50, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates5 = sub5.date
dates5 = dates5.dt.strftime('%B %d')
ax[2, 1].annotate(dates5.iloc[0], (s5x.iloc[0], s5y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 1].annotate(dates5.iloc[-1], (s5x.iloc[-1], s5y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


plt.savefig(r'figure\trace_equity_mobility_p3.jpg' , dpi=100, bbox_inches='tight')
plt.clf()
##### end of Figure 5 ##########


############# Figure A.3 ################
######### for page 4 (Greece, Slovenia, India, Brazil, South Africa, Thailand)

plt.figure(figsize=(7.2,5.8))
plt.rcParams.update({'font.size': 17.5})

fig, ax = plt.subplots(nrows=3, ncols=2, sharex = True, sharey = True,  
                        figsize=(14,18))        

fig.subplots_adjust(left=0.5)

fig.text(0.5, 0,"Percent Workplace Mobility Deviation from Baseline", ha = 'center', fontsize=22)
fig.text(0, 0.3,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()

plt.axis([-82, 27, -101, 27])

sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Greece']
s0x = sub0['workplace_percent_change_from_baseline']
s0y = sub0['stock market percentage change from Feb.17']
s0w = round(sub0['weight'].iloc[0], 4)


sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Slovenia']
s1x = sub1['workplace_percent_change_from_baseline']
s1y = sub1['stock market percentage change from Feb.17']
s1w = round(sub1['weight'].iloc[0], 4)

sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'India']
s2x = sub2['workplace_percent_change_from_baseline']
s2y = sub2['stock market percentage change from Feb.17']
s2w = round(sub2['weight'].iloc[0], 4)

sub3 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Brazil']
s3x = sub3['workplace_percent_change_from_baseline']
s3y = sub3['stock market percentage change from Feb.17']
s3w = round(sub3['weight'].iloc[0], 4)

sub4 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'South Africa']
s4x = sub4['workplace_percent_change_from_baseline']
s4y = sub4['stock market percentage change from Feb.17']
s4w = round(sub4['weight'].iloc[0], 4)

sub5 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Thailand']
s5x = sub5['workplace_percent_change_from_baseline']
s5y = sub5['stock market percentage change from Feb.17']
s5w = round(sub5['weight'].iloc[0], 4)

ax[0, 0].set_title('Greece' + ' (' +"{:.2%}".format(s0w) + ')')
ax[0, 1].set_title('Slovenia' + ' (' +"{:.2%}".format(s1w) + ')')
ax[1, 0].set_title('India' + ' (' +"{:.2%}".format(s2w) + ')')
ax[1, 1].set_title('Brazil' + ' (' +"{:.2%}".format(s3w) + ')')
ax[2, 0].set_title('South Africa' + ' (' +"{:.2%}".format(s4w) + ')')
ax[2, 1].set_title('Thailand' + ' (' +"{:.2%}".format(s5w) + ')')

ax[0, 0].set_frame_on(False)
ax[0, 1].set_frame_on(False)
ax[1, 0].set_frame_on(False)
ax[1, 1].set_frame_on(False)
ax[2, 0].set_frame_on(False)
ax[2, 1].set_frame_on(False)

ax[0, 0].grid(color = 'lavender', alpha = 0.5)
ax[0, 1].grid(color = 'lavender', alpha = 0.5)
ax[1, 0].grid(color = 'lavender', alpha = 0.5)
ax[1, 1].grid(color = 'lavender', alpha = 0.5)
ax[2, 0].grid(color = 'lavender', alpha = 0.5)
ax[2, 1].grid(color = 'lavender', alpha = 0.5)
for ax0 in ax.flat:
    ax0.label_outer()

#x = equity_mob_case_npi.loc[equity_mob_case_npi.country == i]['workplace_percent_change_from_baseline']
ax[0, 0].plot(s0x, s0y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 0].scatter(s0x, s0y, facecolor='lightcyan', edgecolors='royalblue')


ax[0, 1].plot(s1x, s1y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 1].scatter(s1x, s1y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 0].plot(s2x, s2y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 0].scatter(s2x, s2y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 1].plot(s3x, s3y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 1].scatter(s3x, s3y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 0].plot(s4x, s4y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 0].scatter(s4x, s4y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 1].plot(s5x, s5y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 1].scatter(s5x, s5y, facecolor='lightcyan', edgecolors='royalblue')

ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[0], s1y.iloc[0], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[-1], s1y.iloc[-1], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[0], s2y.iloc[0], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[-1], s2y.iloc[-1], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[0], s3y.iloc[0], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[-1], s3y.iloc[-1], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[0], s4y.iloc[0], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[-1], s4y.iloc[-1], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[0], s5y.iloc[0], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[-1], s5y.iloc[-1], c = 'royalblue')
plt.tight_layout()

##### For Greece 0 #######
try:
    x01 = sub0.loc[sub0.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y01 = sub0.loc[sub0.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z01 = sub0.loc[sub0.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x01,y01, s =100, c = 'darkorange')
    ax[0, 0].annotate(z01, (x01, y01), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x02 = sub0.loc[sub0['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y02 = sub0.loc[sub0['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z02 = sub0.loc[sub0['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x02,y02, s = 100, c = 'limegreen')
    ax[0, 0].annotate(z02, (x02, y02), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c03 = sub0.iloc[-30:]
    x03 = c03.loc[c03['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y03 = c03.loc[c03['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z03 = c03.loc[c03['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x03,y03, s =100, c = 'crimson')
    ax[0, 0].annotate(z03,
        xy=(x03, y03), xycoords='data',
        xytext=(-53, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates0 = sub0.date
dates0 = dates0.dt.strftime('%B %d')
ax[0, 0].annotate(dates0.iloc[0], (s0x.iloc[0], s0y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 0].annotate(dates0.iloc[-1], (s0x.iloc[-1], s0y.iloc[-1]), textcoords="offset points",
         xytext=(15,50),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### For Slovenia 1 #######
try:
    x11 = sub1.loc[sub1.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y11 = sub1.loc[sub1.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z11 = sub1.loc[sub1.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x11,y11, s = 100, c = 'darkorange')
    ax[0, 1].annotate(z11, (x11, y11), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-40,-35),ha='center')

except IndexError:
    pass
    
try:
    x12 = sub1.loc[sub1['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y12 = sub1.loc[sub1['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z12 = sub1.loc[sub1['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x12,y12, s = 100, c = 'limegreen')
    ax[0, 1].annotate(z12, (x12, y12), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(40,-65),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c13 = sub1.iloc[-30:]
    x13 = c13.loc[c13['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y13 = c13.loc[c13['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z13 = c13.loc[c13['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x13,y13, s = 100, c = 'crimson')
    ax[0, 1].annotate(z13,
        xy=(x13, y13), xycoords='data',
        xytext=(-60, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates1 = sub1.date
dates1 = dates1.dt.strftime('%B %d')
ax[0, 1].annotate(dates1.iloc[0], (s1x.iloc[0], s1y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 1].annotate(dates1.iloc[-1], (s1x.iloc[-1], s1y.iloc[-1]), textcoords="offset points",
         xytext=(10,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### India 2 #######
try:
    x21 = sub2.loc[sub2.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y21 = sub2.loc[sub2.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z21 = sub2.loc[sub2.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x21,y21, s = 100, c = 'darkorange')
    ax[1, 0].annotate(z21, (x21, y21), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-30,25),ha='center')

except IndexError:
    pass
    
try:
    x22 = sub2.loc[sub2['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y22 = sub2.loc[sub2['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z22 = sub2.loc[sub2['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x22,y22, s = 100, c = 'limegreen')
    ax[1, 0].annotate(z22, (x22, y22), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-40),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c23 = sub2.iloc[-30:]
    x23 = c23.loc[c23['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y23 = c23.loc[c23['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z23 = c23.loc[c23['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x23,y23, s = 100, c = 'crimson')
    ax[1, 0].annotate(z23,
        xy=(x23, y23), xycoords='data',
        xytext=(-50, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates2 = sub2.date
dates2 = dates2.dt.strftime('%B %d')
ax[1, 0].annotate(dates2.iloc[0], (s2x.iloc[0], s2y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 0].annotate(dates2.iloc[-1], (s2x.iloc[-1], s2y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

### Brazil 3 ###
try:
    x31 = sub3.loc[sub3.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y31 = sub3.loc[sub3.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z31 = sub3.loc[sub3.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x31, y31, s = 100, c = 'darkorange')
    ax[1, 1].annotate(z31, (x31, y31), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x32 = sub3.loc[sub3['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = sub3.loc[sub3['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = sub3.loc[sub3['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32, s = 100, c = 'limegreen')
    ax[1, 1].annotate(z32, (x32, y32), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c33 = sub3.iloc[-30:]
    x33 = c33.loc[c33['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y33 = c33.loc[c33['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z33 = c33.loc[c33['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x33,y33, s = 100, c = 'crimson')
    ax[1, 1].annotate(z33,
        xy=(x33, y33), xycoords='data',
        xytext=(30, 50), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates3 = sub3.date
dates3 = dates3.dt.strftime('%B %d')
ax[1, 1].annotate(dates3.iloc[0], (s3x.iloc[0], s3y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 1].annotate(dates3.iloc[-1], (s3x.iloc[-1], s3y.iloc[-1]), textcoords="offset points",
         xytext=(-10,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### South Africa 4 #######
try:
    x41 = sub4.loc[sub4.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y41 = sub4.loc[sub4.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z41 = sub4.loc[sub4.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x41,y41, s = 100, c = 'darkorange')
    ax[2, 0].annotate(z41, (x41, y41), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(0,-25),ha='center')

except IndexError:
    pass
    
try:
    x42 = sub4.loc[sub4['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y42 = sub4.loc[sub4['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z42 = sub4.loc[sub4['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x42,y42, s = 100, c = 'limegreen')
    ax[2, 0].annotate(z42, (x42, y42), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,25),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c43 = sub4.iloc[-30:]
    x43 = c43.loc[c43['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y43 = c43.loc[c43['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z43 = c43.loc[c43['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x43,y43, s =100, c = 'crimson')
    ax[2, 0].annotate(z43,
        xy=(x43, y43), xycoords='data',
        xytext=(-50, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates4 = sub4.date
dates4 = dates4.dt.strftime('%B %d')
ax[2, 0].annotate(dates4.iloc[0], (s4x.iloc[0], s4y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 0].annotate(dates4.iloc[-1], (s4x.iloc[-1], s4y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### Thailand 5 #######
try:
    x51 = sub5.loc[sub5.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y51 = sub5.loc[sub5.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z51 = sub5.loc[sub5.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x51,y51, s = 100, c = 'darkorange')
    ax[2, 1].annotate(z51, (x51, y51), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(20,-45),ha='center')

except IndexError:
    pass
    
try:
    x52 = sub5.loc[sub5['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y52 = sub5.loc[sub5['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z52 = sub5.loc[sub5['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x52,y52, s = 100, c = 'limegreen')
    ax[2, 1].annotate(z52, (x52, y52), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-25,-40),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c53 = sub5.iloc[-30:]
    x53 = c53.loc[c53['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y53 = c53.loc[c53['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z53 = c53.loc[c53['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x53,y53, s = 100, c = 'crimson')
    ax[2, 1].annotate(z53,
        xy=(x53, y53), xycoords='data',
        xytext=(0, 40), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates5 = sub5.date
dates5 = dates5.dt.strftime('%B %d')
ax[2, 1].annotate(dates5.iloc[0], (s5x.iloc[0], s5y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 1].annotate(dates5.iloc[-1], (s5x.iloc[-1], s5y.iloc[-1]), textcoords="offset points",
         xytext=(-35,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


plt.savefig(r'figure\trace_equity_mobility_p4.jpg' , dpi=100, bbox_inches='tight')
plt.clf()


###  page 5 (Malaysia, Mexico, Chile, Qatar, Turkey, Romania)

plt.figure(figsize=(7.2,5.8))
plt.rcParams.update({'font.size': 17.5})

fig, ax = plt.subplots(nrows=3, ncols=2, sharex = True, sharey = True,  
                        figsize=(14,18))        
fig.subplots_adjust(left = 0.5, bottom = 0.5)

fig.text(0.5, 0,"Percent Workplace Mobility Deviation from Baseline", ha = 'center', fontsize=22)
fig.text(0, 0.3,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()

plt.axis([-82, 27, -82, 27])

sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Malaysia']
s0x = sub0['workplace_percent_change_from_baseline']
s0y = sub0['stock market percentage change from Feb.17']
s0w = round(sub0['weight'].iloc[0], 4)

sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Mexico']
s1x = sub1['workplace_percent_change_from_baseline']
s1y = sub1['stock market percentage change from Feb.17']
s1w = round(sub1['weight'].iloc[0], 4)

sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Chile']
s2x = sub2['workplace_percent_change_from_baseline']
s2y = sub2['stock market percentage change from Feb.17']
s2w = round(sub2['weight'].iloc[0], 4)

sub3 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Qatar']
s3x = sub3['workplace_percent_change_from_baseline']
s3y = sub3['stock market percentage change from Feb.17']
s3w = round(sub3['weight'].iloc[0], 4)

sub4 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Turkey']
s4x = sub4['workplace_percent_change_from_baseline']
s4y = sub4['stock market percentage change from Feb.17']
s4w = round(sub4['weight'].iloc[0], 4)

sub5 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Romania']
s5x = sub5['workplace_percent_change_from_baseline']
s5y = sub5['stock market percentage change from Feb.17']
s5w = round(sub5['weight'].iloc[0], 4)


ax[0, 0].set_title('Malaysia' + ' (' +"{:.2%}".format(s0w) + ')')
ax[0, 1].set_title('Mexico' + ' (' +"{:.2%}".format(s1w) + ')')
ax[1, 0].set_title('Chile' + ' (' +"{:.2%}".format(s2w) + ')')
ax[1, 1].set_title('Qatar' + ' (' +"{:.2%}".format(s3w) + ')')
ax[2, 0].set_title('Turkey' + ' (' +"{:.2%}".format(s4w) + ')')
ax[2, 1].set_title('Romania' + ' (' +"{:.2%}".format(s5w) + ')')

ax[0, 0].set_frame_on(False)
ax[0, 1].set_frame_on(False)
ax[1, 0].set_frame_on(False)
ax[1, 1].set_frame_on(False)
ax[2, 0].set_frame_on(False)
ax[2, 1].set_frame_on(False)

ax[0, 0].grid(color = 'lavender', alpha = 0.5)
ax[0, 1].grid(color = 'lavender', alpha = 0.5)
ax[1, 0].grid(color = 'lavender', alpha = 0.5)
ax[1, 1].grid(color = 'lavender', alpha = 0.5)
ax[2, 0].grid(color = 'lavender', alpha = 0.5)
ax[2, 1].grid(color = 'lavender', alpha = 0.5)

for ax0 in ax.flat:
    ax0.label_outer()

ax[0, 0].plot(s0x, s0y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 0].scatter(s0x, s0y, facecolor='lightcyan', edgecolors='royalblue')


ax[0, 1].plot(s1x, s1y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 1].scatter(s1x, s1y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 0].plot(s2x, s2y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 0].scatter(s2x, s2y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 1].plot(s3x, s3y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 1].scatter(s3x, s3y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 0].plot(s4x, s4y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 0].scatter(s4x, s4y, facecolor='lightcyan', edgecolors='royalblue')

ax[2, 1].plot(s5x, s5y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[2, 1].scatter(s5x, s5y, facecolor='lightcyan', edgecolors='royalblue')

ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[0], s1y.iloc[0], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[-1], s1y.iloc[-1], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[0], s2y.iloc[0], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[-1], s2y.iloc[-1], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[0], s3y.iloc[0], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[-1], s3y.iloc[-1], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[0], s4y.iloc[0], c = 'royalblue')
ax[2, 0].scatter(s4x.iloc[-1], s4y.iloc[-1], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[0], s5y.iloc[0], c = 'royalblue')
ax[2, 1].scatter(s5x.iloc[-1], s5y.iloc[-1], c = 'royalblue')

plt.tight_layout()

##### Malaysia 0 #######
try:
    x01 = sub0.loc[sub0.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y01 = sub0.loc[sub0.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z01 = sub0.loc[sub0.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x01,y01, s = 100, c = 'darkorange')
    ax[0, 0].annotate(z01, (x01, y01), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x02 = sub0.loc[sub0['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y02 = sub0.loc[sub0['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z02 = sub0.loc[sub0['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x02,y02, s = 100, c = 'limegreen')
    ax[0, 0].annotate(z02, (x02, y02), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c03 = sub0.iloc[-30:]
    x03 = c03.loc[c03['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y03 = c03.loc[c03['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z03 = c03.loc[c03['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x03,y03, s = 100, c = 'crimson')
    ax[0, 0].annotate(z03,
        xy=(x03, y03), xycoords='data',
        xytext=(-40, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass


dates0 = sub0.date
dates0 = dates0.dt.strftime('%B %d')
ax[0, 0].annotate(dates0.iloc[0], (s0x.iloc[0], s0y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 0].annotate(dates0.iloc[-1], (s0x.iloc[-1], s0y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


### Mexico 1 ###
try:
    x11 = sub1.loc[sub1.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y11 = sub1.loc[sub1.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z11 = sub1.loc[sub1.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x11,y11, s =100, c = 'darkorange')
    ax[0, 1].annotate(z11, (x11, y11), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x12 = sub1.loc[sub1['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y12 = sub1.loc[sub1['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z12 = sub1.loc[sub1['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x12,y12, s =100, c = 'limegreen')
    ax[0, 1].annotate(z12, (x12, y12), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c13 = sub1.iloc[-30:]
    x13 = c13.loc[c13['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y13 = c13.loc[c13['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z13 = c13.loc[c13['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x13,y13, s = 100, c = 'crimson')
    ax[0, 1].annotate(z13,
        xy=(x13, y13), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates1 = sub1.date
dates1 = dates1.dt.strftime('%B %d')
ax[0, 1].annotate(dates1.iloc[0], (s1x.iloc[0], s1y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 1].annotate(dates1.iloc[-1], (s1x.iloc[-1], s1y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### Chile 2 #######
try:
    x21 = sub2.loc[sub2.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y21 = sub2.loc[sub2.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z21 = sub2.loc[sub2.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x21,y21, s =100, c = 'darkorange')
    ax[1, 0].annotate(z21, (x21, y21), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x22 = sub2.loc[sub2['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y22 = sub2.loc[sub2['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z22 = sub2.loc[sub2['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x22,y22, s =100, c = 'limegreen')
    ax[1, 0].annotate(z22, (x22, y22), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-35,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c23 = sub2.iloc[-30:]
    x23 = c23.loc[c23['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y23 = c23.loc[c23['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z23 = c23.loc[c23['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x23,y23, s = 100, c = 'crimson')
    ax[1, 0].annotate(z23,
        xy=(x23, y23), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates2 = sub2.date
dates2 = dates2.dt.strftime('%B %d')
ax[1, 0].annotate(dates2.iloc[0], (s2x.iloc[0], s2y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 0].annotate(dates2.iloc[-1], (s2x.iloc[-1], s2y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Qatar 3 #######
try:
    x31 = sub3.loc[sub3.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y31 = sub3.loc[sub3.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z31 = sub3.loc[sub3.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x31,y31, s = 100, c = 'darkorange')
    ax[1, 1].annotate(z31, (x31, y31), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-25,-35),ha='center')

except IndexError:
    pass
    
try:
    x32 = sub3.loc[sub3['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = sub3.loc[sub3['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = sub3.loc[sub3['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32, s = 100, c = 'limegreen')
    ax[1, 1].annotate(z32, (x32, y32), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(25,-60),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c33 = sub3.iloc[-30:]
    x33 = c33.loc[c33['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y33 = c33.loc[c33['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z33 = c33.loc[c33['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x33,y33, s = 100, c = 'crimson')
    ax[1, 1].annotate(z33,
        xy=(x33, y33), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass


dates3 = sub3.date
dates3 = dates3.dt.strftime('%B %d')
ax[1, 1].annotate(dates3.iloc[0], (s3x.iloc[0], s3y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 1].annotate(dates3.iloc[-1], (s3x.iloc[-1], s3y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


##### Turkey 4 #######
try:
    x41 = sub4.loc[sub4.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y41 = sub4.loc[sub4.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z41 = sub4.loc[sub4.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x41,y41, s = 100, c = 'darkorange')
    ax[2, 0].annotate(z41, (x41, y41), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-30,-35),ha='center')

except IndexError:
    pass
    
try:
    x42 = sub4.loc[sub4['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y42 = sub4.loc[sub4['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z42 = sub4.loc[sub4['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x42,y42, s =100, c = 'limegreen')
    ax[2, 0].annotate(z42, (x42, y42), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c43 = sub4.iloc[-30:]
    x43 = c43.loc[c43['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y43 = c43.loc[c43['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z43 = c43.loc[c43['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 0].scatter(x43,y43, s = 100, c = 'crimson')
    ax[2, 0].annotate(z43,
        xy=(x43, y43), xycoords='data',
        xytext=(-40, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates4 = sub4.date
dates4 = dates4.dt.strftime('%B %d')
ax[2, 0].annotate(dates4.iloc[0], (s4x.iloc[0], s4y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 0].annotate(dates4.iloc[-1], (s4x.iloc[-1], s4y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Romania 5 #######
try:
    x51 = sub5.loc[sub5.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y51 = sub5.loc[sub5.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z51 = sub5.loc[sub5.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x51,y51, s = 200, c = 'darkorange')
    ax[2, 1].annotate(z51, (x51, y51), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(50,-35),ha='center')

except IndexError:
    pass
    
try:
    x52 = sub5.loc[sub5['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y52 = sub5.loc[sub5['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z52 = sub5.loc[sub5['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x52,y52, s = 100, c = 'limegreen')
    ax[2, 1].annotate(z52, (x52, y52), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-30,-60),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c53 = sub5.iloc[-30:]
    x53 = c53.loc[c53['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y53 = c53.loc[c53['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z53 = c53.loc[c53['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[2, 1].scatter(x53, y53, s = 100, c = 'crimson')
    ax[2, 1].annotate(z53,
        xy=(x53, y53), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates5 = sub5.date
dates5 = dates5.dt.strftime('%B %d')
ax[2, 1].annotate(dates5.iloc[0], (s5x.iloc[0], s5y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[2, 1].annotate(dates5.iloc[-1], (s5x.iloc[-1], s5y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))


plt.savefig(r'figure\trace_equity_mobility_p5.jpg' , dpi=100, bbox_inches='tight')
plt.clf()

### page 6 # Argentina, Kazakhstan, Hungary, Croatia

plt.figure(figsize=(7.2,5.8))
plt.rcParams.update({'font.size': 17.5})

fig, ax = plt.subplots(nrows=2, ncols=2, sharex = True, sharey = True,  
                        figsize=(14,12))        
fig.subplots_adjust(left = 0.5, bottom = 0.5)

fig.text(0.5, 0,"Percent Workplace Mobility Deviation from Baseline", ha = 'center', fontsize=22)
fig.text(0, 0.15,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', rotation = 'vertical', fontsize= 22)
plt.tight_layout()

plt.axis([-82, 27, -70, 27])

sub0 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Argentina']
s0x = sub0['workplace_percent_change_from_baseline']
s0y = sub0['stock market percentage change from Feb.17']
s0w = round(sub0['weight'].iloc[0], 4)

sub1 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Kazakhstan']
s1x = sub1['workplace_percent_change_from_baseline']
s1y = sub1['stock market percentage change from Feb.17']
s1w = round(sub1['weight'].iloc[0], 4)

sub2 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Hungary']
s2x = sub2['workplace_percent_change_from_baseline']
s2y = sub2['stock market percentage change from Feb.17']
s2w = round(sub2['weight'].iloc[0], 4)

sub3 = equity_mob_death_npi.loc[equity_mob_death_npi.country == 'Croatia']
s3x = sub3['workplace_percent_change_from_baseline']
s3y = sub3['stock market percentage change from Feb.17']
s3w = round(sub3['weight'].iloc[0], 4)

ax[0, 0].set_title('Argentina' + ' (' +"{:.2%}".format(s0w) + ')')
ax[0, 1].set_title('Kazakhstan' + ' (' +"{:.2%}".format(s1w) + ')')
ax[1, 0].set_title('Hungary' + ' (' +"{:.2%}".format(s2w) + ')')
ax[1, 1].set_title('Crotia' + ' (' +"{:.2%}".format(s2w) + ')')

ax[0, 0].set_frame_on(False)
ax[0, 1].set_frame_on(False)
ax[1, 0].set_frame_on(False)
ax[1, 1].set_frame_on(False)


ax[0, 0].grid(color = 'lavender', alpha = 0.5)
ax[0, 1].grid(color = 'lavender', alpha = 0.5)
ax[1, 0].grid(color = 'lavender', alpha = 0.5)
ax[1, 1].grid(color = 'lavender', alpha = 0.5)

for ax0 in ax.flat:
    ax0.label_outer()

ax[0, 0].plot(s0x, s0y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 0].scatter(s0x, s0y, facecolor='lightcyan', edgecolors='royalblue')


ax[0, 1].plot(s1x, s1y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[0, 1].scatter(s1x, s1y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 0].plot(s2x, s2y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 0].scatter(s2x, s2y, facecolor='lightcyan', edgecolors='royalblue')

ax[1, 1].plot(s3x, s3y, fillstyle='full', color = 'grey',linewidth=0.5)
ax[1, 1].scatter(s3x, s3y, facecolor='lightcyan', edgecolors='royalblue')


ax[0, 0].scatter(s0x.iloc[0], s0y.iloc[0], c = 'royalblue')
ax[0, 0].scatter(s0x.iloc[-1], s0y.iloc[-1], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[0], s1y.iloc[0], c = 'royalblue')
ax[0, 1].scatter(s1x.iloc[-1], s1y.iloc[-1], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[0], s2y.iloc[0], c = 'royalblue')
ax[1, 0].scatter(s2x.iloc[-1], s2y.iloc[-1], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[0], s3y.iloc[0], c = 'royalblue')
ax[1, 1].scatter(s3x.iloc[-1], s3y.iloc[-1], c = 'royalblue')

plt.tight_layout()


##### Argentina 0 #######
try:
    x01 = sub0.loc[sub0.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y01 = sub0.loc[sub0.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z01 = sub0.loc[sub0.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x01, y01, s = 100, c = 'darkorange')
    ax[0, 0].annotate(z01, (x01, y01), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-40,-35),ha='center')

except IndexError:
    pass
    
try:
    x02 = sub0.loc[sub0['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y02 = sub0.loc[sub0['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z02 = sub0.loc[sub0['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x02,y02, s =100, c = 'limegreen')
    ax[0, 0].annotate(z02, (x02, y02), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-15,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c03 = sub0.iloc[-30:]
    x03 = c03.loc[c03['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y03 = c03.loc[c03['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z03 = c03.loc[c03['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 0].scatter(x03,y03,  s = 100, c = 'crimson')
    ax[0, 0].annotate(z03,
        xy=(x03, y03), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass



dates0 = sub0.date
dates0 = dates0.dt.strftime('%B %d')
ax[0, 0].annotate(dates0.iloc[0], (s0x.iloc[0], s0y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 0].annotate(dates0.iloc[-1], (s0x.iloc[-1], s0y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

### Kazakhstan 1 ###
try:
    x11 = sub1.loc[sub1.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y11 = sub1.loc[sub1.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z11 = sub1.loc[sub1.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x11,y11, s =100, c = 'darkorange')
    ax[0, 1].annotate(z11, (x11, y11), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-40,-35),ha='center')

except IndexError:
    pass
    
try:
    x12 = sub1.loc[sub1['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y12 = sub1.loc[sub1['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z12 = sub1.loc[sub1['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x12,y12, s =100, c = 'limegreen')
    ax[0, 1].annotate(z12, (x12, y12), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c13 = sub1.iloc[-30:]
    x13 = c13.loc[c13['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y13 = c13.loc[c13['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z13 = c13.loc[c13['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[0, 1].scatter(x13,y13, s = 100, c = 'crimson')
    ax[0, 1].annotate(z13,
        xy=(x13, y13), xycoords='data',
        xytext=(-20, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass


dates1 = sub1.date
dates1 = dates1.dt.strftime('%B %d')
ax[0, 1].annotate(dates1.iloc[0], (s1x.iloc[0], s1y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[0, 1].annotate(dates0.iloc[-1], (s1x.iloc[-1], s1y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Hungary 2 #######
try:
    x21 = sub2.loc[sub2.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y21 = sub2.loc[sub2.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z21 = sub2.loc[sub2.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x21,y21, s =100, c = 'darkorange')
    ax[1, 0].annotate(z21, (x21, y21), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(30,-35),ha='center')

except IndexError:
    pass
    
try:
    x22 = sub2.loc[sub2['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y22 = sub2.loc[sub2['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z22 = sub2.loc[sub2['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x22,y22, s =100, c = 'limegreen')
    ax[1, 0].annotate(z22, (x22, y22), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-35,-45),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c23 = sub2.iloc[-30:]
    x23 = c23.loc[c23['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y23 = c23.loc[c23['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z23 = c23.loc[c23['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 0].scatter(x23,y23, s = 100, c = 'crimson')
    ax[1, 0].annotate(z23,
        xy=(x23, y23), xycoords='data',
        xytext=(-55, 30), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

except IndexError:
    pass

dates2 = sub2.date
dates2 = dates2.dt.strftime('%B %d')
ax[1, 0].annotate(dates2.iloc[0], (s2x.iloc[0], s2y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 0].annotate(dates2.iloc[-1], (s2x.iloc[-1], s2y.iloc[-1]), textcoords="offset points",
         xytext=(20,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

##### Crotia 3 #######
try:
    x31 = sub3.loc[sub3.death>0]['workplace_percent_change_from_baseline'].iloc[0]
    y31 = sub3.loc[sub3.death>0]['stock market percentage change from Feb.17'].iloc[0]
    z31 = sub3.loc[sub3.death>0]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x31,y31, s = 100, c = 'darkorange')
    ax[1, 1].annotate(z31, (x31, y31), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(25,-35),ha='center')

except IndexError:
    pass
    
try:
    x32 = sub3.loc[sub3['Stringency Index'] >70]['workplace_percent_change_from_baseline'].iloc[0]
    y32 = sub3.loc[sub3['Stringency Index'] >70]['stock market percentage change from Feb.17'].iloc[0]
    z32 = sub3.loc[sub3['Stringency Index'] >70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x32,y32, s = 100, c = 'limegreen')
    ax[1, 1].annotate(z32, (x32, y32), textcoords="offset points",arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"),
                 xytext=(-25,-60),ha='center') #, bbox=dict(boxstyle="round4", fc="w")

except IndexError:
    pass

try:
    c33 = sub3.iloc[-30:]
    x33 = c33.loc[c33['Stringency Index'] <=70]['workplace_percent_change_from_baseline'].iloc[0]
    y33 = c33.loc[c33['Stringency Index'] <=70]['stock market percentage change from Feb.17'].iloc[0]
    z33 = c33.loc[c33['Stringency Index'] <=70]['date'].dt.strftime('%B %d').iloc[0]
    ax[1, 1].scatter(x33,y33, s = 100, c = 'crimson')
    ax[1, 1].annotate(z33,
        xy=(x33, y33), xycoords='data',
        xytext=(20, 20), textcoords='offset points',
        arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))
except IndexError:
    pass

dates3 = sub3.date
dates3 = dates3.dt.strftime('%B %d')
ax[1, 1].annotate(dates3.iloc[0], (s3x.iloc[0], s3y.iloc[0]), textcoords="offset points",
             xytext=(0,10),ha='center')
ax[1, 1].annotate(dates3.iloc[-1], (s3x.iloc[-1], s3y.iloc[-1]), textcoords="offset points",
         xytext=(0,30),ha='center', arrowprops=dict(arrowstyle="->",
                        connectionstyle="arc3"))

plt.savefig(r'figure\trace_equity_mobility_p6.jpg' , dpi=100, bbox_inches='tight')
plt.clf()
