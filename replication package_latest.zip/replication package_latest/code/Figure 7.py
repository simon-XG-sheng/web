# -*- coding: utf-8 -*-
"""
Created on Sat Aug 15 18:15:00 2020

This script is to make plots for "Stock Prices and Economic Activity in the Time of Coronavirus" 

@author: Dingqian Liu American University Ph.D. Candidate in Economics
@contact: dl5165a@american.edu; https://dingqianl.github.io/web/

"""

import pandas as pd
import os 
import matplotlib.pyplot as plt

path = r'...\replication package_latest'
os.chdir(path)

equity_mob_death_npi = pd.read_csv(r'data\data_individual plots.csv')
equity_mob_death_npi['date'] = pd.to_datetime(equity_mob_death_npi['date'])

####### to find out outliers figure 7 ###
#### scatterplot of workplace mobility deviation vs stock market deviation/stringency index on 30 March 2020

equity_mob_death_npi_outlier = equity_mob_death_npi.loc[equity_mob_death_npi['date'] =='2020-03-30' ]

c1 = equity_mob_death_npi_outlier.country.to_list()
x1 = equity_mob_death_npi_outlier['stock market percentage change from Feb.17'].to_list()
y1 = equity_mob_death_npi_outlier['workplace_percent_change_from_baseline'].to_list()

plt.rcParams.update({'font.size': 12})
plt.figure(figsize=(20,19))
fig, ax = plt.subplots()

ax.set_frame_on(False)
ax.grid(color = 'lavender', alpha = 0.5)

ax.scatter(x1, y1, facecolor='skyblue', edgecolors='mediumblue')

fig.text(0.5, -0.1,"Percent Stock Market Deviation from 17 February 2020", ha = 'center', fontsize=12)
fig.text(0, -0.1, "Percent Workplace Mobility Deviation from Baseline", ha = 'center', rotation = 'vertical', fontsize= 12)

plt.axis([-65, 0, -80, 20])
ax.set_yticks(range(-70,11,20))

for i, txt in enumerate(c1):
    ax.annotate(txt, (x1[i], y1[i]), fontsize = 11)

plt.axvline(x= -30, color='darkorange', linestyle='--')
plt.axhline(y= -30, color='darkorange', linestyle='--')


plt.savefig(r'figure\figure7_outliers1.jpg' , dpi=100, bbox_inches = "tight")
plt.clf()

#### for the right side of outlier graph
c1 = equity_mob_death_npi_outlier.country.to_list()
x1 = equity_mob_death_npi_outlier['StringencyIndex'].to_list()
y1 = equity_mob_death_npi_outlier['workplace_percent_change_from_baseline'].to_list()

plt.rcParams.update({'font.size': 12})
plt.figure(figsize=(20,19))
fig, ax = plt.subplots()

ax.set_frame_on(False)
ax.grid(color = 'lavender', alpha = 0.5)

ax.scatter(x1, y1, facecolor='skyblue', edgecolors='mediumblue')

fig.text(0.5, -0.1,"Stringency Index", ha = 'center', fontsize=12)
fig.text(0, -0.1, "Percent Workplace Mobility Deviation from Baseline", ha = 'center', rotation = 'vertical', fontsize= 12)

plt.axis([20, 110, -80, 20])
ax.set_yticks(range(-70,11,20))

for i, txt in enumerate(c1):
    ax.annotate(txt, (x1[i], y1[i]), fontsize = 11)

plt.axvline(x= 70, color='darkorange', linestyle='--')
plt.axhline(y= -30, color='darkorange', linestyle='--')

plt.savefig(r'figure\figure7_outliers2.jpg' , dpi=100, bbox_inches = "tight")
plt.clf()